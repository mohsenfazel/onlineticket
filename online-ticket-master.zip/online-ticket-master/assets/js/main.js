jQuery(document).ready(function () {
    alert('123');
});