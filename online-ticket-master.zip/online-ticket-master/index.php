<?php get_header(); ?>
<?php get_template_part( 'partials/top-header' ); ?>
<?php get_template_part( 'partials/main-content' ); ?>
<?php get_template_part( 'partials/move-text' ); ?>
<?php get_template_part( 'partials/move-text' ); ?>
<?php get_template_part( 'partials/banner-bottom' ); ?>
<?php get_template_part( 'partials/popular-grids' ); ?>
<?php get_template_part( 'partials/footer' ); ?>
<?php get_template_part( 'partials/footer-bottom-grids' ); ?>
<?php get_footer(); ?>
